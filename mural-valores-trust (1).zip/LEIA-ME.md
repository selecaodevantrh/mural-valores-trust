# Mural dos Valores – Trust Control

O mural guarda os registros e os apoios no próprio Netlify (Netlify Blobs). Tudo aparece na hora para o time, sem curadoria prévia.

## O que tem nesta pasta

| Arquivo | Para quê |
|---|---|
| `index.html` | O mural que vai para o time |
| `admin.html` | Painel do RH: ocultar registros, exportar planilha, encerrar a coleta |
| `netlify/functions/mural.mjs` | A função que salva e conta registros e apoios |
| `package.json`, `netlify.toml` | Configuração para o Netlify |

## Publicar (uma vez só)

Como o mural tem uma função de servidor, **não dá para publicar arrastando a pasta** no Netlify. Use um dos caminhos:

### Caminho A – GitHub (recomendado, mais fácil de atualizar depois)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta, mantendo as subpastas.
2. No Netlify: **Add new project → Import an existing project → GitHub** e escolha o repositório.
3. Deixe o *Build command* vazio e o *Publish directory* como `.` e clique em **Deploy**.
4. Faça o passo **"Criar a senha do RH"** abaixo.

A partir daí, qualquer alteração enviada ao GitHub é publicada sozinha.

### Caminho B – Linha de comando
1. Instale o Node.js (versão 18 ou mais nova).
2. Abra o terminal nesta pasta e rode:
   ```
   npm install
   npx netlify-cli login
   npx netlify-cli deploy --prod
   ```
3. Escolha criar um novo site (ou ligar a um existente).
4. Faça o passo **"Criar a senha do RH"** abaixo.

## Criar a senha do RH
1. No Netlify, abra o site → **Project configuration → Environment variables → Add a variable**.
2. Nome: `ADMIN_KEY` · Valor: a senha que o RH vai usar.
3. Publique de novo (**Deploys → Trigger deploy → Deploy project**) para a senha valer.
4. Acesse `seu-site.netlify.app/admin.html` e entre com a senha.

## Uso no dia a dia
- **Link para o time:** `seu-site.netlify.app` (abre direto na Credibilidade).
- **Ocultar** um registro (nomes, desrespeito): pelo `admin.html`. Ele some do mural na hora.
- **Exportar** tudo para Excel: botão "Exportar planilha (CSV)".
- **Encerrar a coleta:** botão "Encerrar coleta". Ninguém mais escreve ou apoia.

## Abrir o próximo valor
No `index.html`, no bloco **CONFIGURAÇÃO** do script:
1. Credibilidade: troque `status:"aberto"` por `status:"concluido"` e preencha `comportamentos` com os 4 escolhidos no PDL. Os registros continuam aparecendo, só para consulta.
2. Confiança (ou Competência): troque `status:"bloqueado"` por `status:"aberto"` e preencha `frase` e `missoes`, seguindo o modelo da Credibilidade.

## Regras de apoio
- Cada pessoa tem **3 apoios por missão** ("reforça" e "enfraquece") e pode retirar um apoio para trocar.
- Sem login, o controle é feito pelo navegador: quem trocar de navegador ou de aparelho consegue apoiar de novo. Para um diagnóstico de cultura isso costuma ser suficiente.
