// Mural dos Valores – Trust Control
// Guarda registros e apoios no Netlify Blobs. Cada registro e cada apoio é uma chave
// separada, então envios simultâneos nunca se sobrescrevem.
import { getStore } from "@netlify/blobs";

const VALORES = ["credibilidade", "confianca", "competencia"]; // valores que podem receber registros
const MAX_APOIOS = 3;          // apoios por pessoa, em cada missão
const MIN_TXT = 8, MAX_TXT = 400;
const CACHE_MS = 8000;         // a leitura pública é recalculada no máximo a cada 8 s

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const clean = (s, n = 64) => String(s || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, n);
const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

async function listKeys(store, prefix) {
  const { blobs } = await store.list({ prefix });
  return blobs.map(b => b.key);
}

async function snapshot(store, valor, { incluirOcultos = false } = {}) {
  const [regKeys, apoioKeys, ocultoKeys, fechado] = await Promise.all([
    listKeys(store, `${valor}/r/`),
    listKeys(store, `${valor}/a/`),
    listKeys(store, `${valor}/h/`),
    store.get(`${valor}/fechado`)
  ]);
  const ocultos = new Set(ocultoKeys.map(k => k.split("/")[2]));
  const regs = (await Promise.all(regKeys.map(k => store.get(k, { type: "json" })))).filter(Boolean);
  const apoios = {};
  for (const k of apoioKeys) { const id = k.split("/")[3]; apoios[id] = (apoios[id] || 0) + 1; }
  const registros = regs
    .filter(r => incluirOcultos || !ocultos.has(r.id))
    .map(r => ({ id: r.id, m: r.m, t: r.t, ts: r.ts, v: apoios[r.id] || 0, ...(incluirOcultos ? { oculto: ocultos.has(r.id) } : {}) }))
    .sort((a, b) => a.ts - b.ts);
  return { valor, fechado: !!fechado, registros, apoioKeys };
}

export default async (req) => {
  const store = getStore({ name: "mural-valores", consistency: "strong" });
  const url = new URL(req.url);
  const isAdmin = !!process.env.ADMIN_KEY && req.headers.get("x-admin-key") === process.env.ADMIN_KEY;

  try {
    if (req.method === "GET") {
      const valor = clean(url.searchParams.get("valor"));
      if (!VALORES.includes(valor)) return json({ erro: "valor inválido" }, 400);
      const device = clean(url.searchParams.get("d"));
      if (url.searchParams.get("admin")) {
        if (!isAdmin) return json({ erro: "senha incorreta" }, 401);
        const s = await snapshot(store, valor, { incluirOcultos: true });
        return json({ valor, fechado: s.fechado, registros: s.registros });
      }
      // cache curto para aguentar muita gente abrindo ao mesmo tempo
      let cache = await store.get(`${valor}/cache`, { type: "json" });
      let apoioKeys;
      if (!cache || Date.now() - cache.at > CACHE_MS) {
        const s = await snapshot(store, valor);
        cache = { at: Date.now(), fechado: s.fechado, registros: s.registros };
        apoioKeys = s.apoioKeys;
        await store.setJSON(`${valor}/cache`, cache);
      }
      // apoios desta pessoa (sempre atualizados, não vêm do cache)
      if (!apoioKeys) apoioKeys = device ? await listKeys(store, `${valor}/a/`) : [];
      const meus = device ? apoioKeys.filter(k => k.endsWith("/" + device)).map(k => k.split("/")[3]) : [];
      return json({ valor, fechado: cache.fechado, registros: cache.registros, meusApoios: meus, maxApoios: MAX_APOIOS });
    }

    if (req.method !== "POST") return json({ erro: "método não permitido" }, 405);
    const body = await req.json().catch(() => ({}));
    const valor = clean(body.valor);
    if (!VALORES.includes(valor)) return json({ erro: "valor inválido" }, 400);
    const acao = body.acao;

    // ---------- ações do RH ----------
    if (["ocultar", "mostrar", "encerrar", "reabrir"].includes(acao)) {
      if (!isAdmin) return json({ erro: "senha incorreta" }, 401);
      const id = clean(body.id);
      if (acao === "ocultar") await store.set(`${valor}/h/${id}`, "1");
      if (acao === "mostrar") await store.delete(`${valor}/h/${id}`);
      if (acao === "encerrar") await store.set(`${valor}/fechado`, "1");
      if (acao === "reabrir") await store.delete(`${valor}/fechado`);
      await store.delete(`${valor}/cache`);
      return json({ ok: true });
    }

    if (await store.get(`${valor}/fechado`)) return json({ erro: "Este mural está encerrado." }, 403);
    const device = clean(body.d);
    if (!device) return json({ erro: "dispositivo não identificado" }, 400);

    // ---------- registrar ----------
    if (acao === "registrar") {
      const m = body.m === 1 ? 1 : 0;
      const t = String(body.t || "").replace(/\s+/g, " ").trim();
      if (t.length < MIN_TXT || t.length > MAX_TXT) return json({ erro: `O registro precisa ter entre ${MIN_TXT} e ${MAX_TXT} caracteres.` }, 400);
      const id = newId();
      await store.setJSON(`${valor}/r/${id}`, { id, m, t, ts: Date.now() });
      await store.delete(`${valor}/cache`);
      return json({ ok: true, id });
    }

    // ---------- apoiar / retirar apoio ----------
    if (acao === "apoiar" || acao === "desapoiar") {
      const id = clean(body.id);
      const reg = await store.get(`${valor}/r/${id}`, { type: "json" });
      if (!reg) return json({ erro: "registro não encontrado" }, 404);
      const key = `${valor}/a/${reg.m}/${id}/${device}`;
      if (acao === "desapoiar") {
        await store.delete(key);
      } else {
        const meus = (await listKeys(store, `${valor}/a/${reg.m}/`)).filter(k => k.endsWith("/" + device));
        if (!meus.includes(key)) {
          if (meus.length >= MAX_APOIOS) return json({ erro: `Você já usou seus ${MAX_APOIOS} apoios nesta missão. Retire um para apoiar outro.` }, 409);
          await store.set(key, "1");
        }
      }
      await store.delete(`${valor}/cache`);
      return json({ ok: true });
    }

    return json({ erro: "ação inválida" }, 400);
  } catch (e) {
    console.error(e);
    return json({ erro: "Erro no servidor. Tente de novo em instantes." }, 500);
  }
};

export const config = { path: "/api/mural" };
